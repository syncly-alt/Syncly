import 'dart:async';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

import '../models/room.dart';

/// Снимок состояния плеера, который пишет админ и читают зрители.
class VideoState {
  final double position;
  final bool playing;
  final double duration;
  final DateTime updatedAt; // серверное время записи
  final String updatedBy;

  const VideoState({
    required this.position,
    required this.playing,
    required this.updatedAt,
    required this.updatedBy,
    this.duration = 0,
  });

  /// Максимум, на сколько секунд экстраполируем вперёд. Heartbeat идёт раз в
  /// 5 с, так что >15 с значит «хост пропал» — не убегаем в никуда.
  static const _maxExtrapolation = 15.0;

  /// Позиция с учётом времени, прошедшего с момента записи.
  /// [serverNow] — текущее время по часам СЕРВЕРА (с поправкой на сдвиг
  /// часов устройства), иначе расхождение часов даёт постоянную ошибку.
  double extrapolatedAt(DateTime serverNow) {
    if (!playing) return position;
    final elapsed = (serverNow.difference(updatedAt).inMilliseconds / 1000.0)
        .clamp(0.0, _maxExtrapolation);
    var result = position + elapsed;
    if (duration > 0 && result > duration) result = duration;
    return result < 0 ? 0 : result;
  }

  /// null, если `updatedAt` ещё не подтверждён сервером.
  static VideoState? tryParse(Map<String, dynamic> m) {
    final ts = m['updatedAt'];
    if (ts is! Timestamp) return null;
    return VideoState(
      position: (m['videoPosition'] ?? 0).toDouble(),
      playing: m['videoPlaying'] ?? false,
      duration: (m['videoDuration'] ?? 0).toDouble(),
      updatedAt: ts.toDate(),
      updatedBy: m['updatedBy'] as String? ?? '',
    );
  }
}

/// Минимальный интерфейс, который должен реализовать любой плеер.
abstract class SyncPlayer {
  Future<void> play();
  Future<void> pause();
  Future<void> seekTo(double seconds);
  Future<double> getCurrentPosition();
  Future<bool> isPlaying();
  Future<double> getDuration();
}

class SyncController extends ChangeNotifier {
  final FirebaseFirestore _db;
  final String roomId;
  final String myUid;

  SyncPlayer? _player;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _sub;
  Timer? _heartbeat;
  Timer? _resync;
  Timer? _staleWatch;

  bool _disposed = false;
  bool _isAdmin = false;
  bool _roomMissing = false;

  Room? _room;
  String? _roomSig;
  VideoState? _remote;
  DateTime? _hostLastSeen;

  /// serverTime − localTime. Лечит расхождение часов между устройствами.
  Duration _serverOffset = Duration.zero;

  bool _applying = false;
  bool _reapply = false;
  DateTime _lastSeekAt = DateTime.fromMillisecondsSinceEpoch(0);

  /// Пока не истекло — события плеера считаем «эхом» наших же команд.
  DateTime _suppressUntil = DateTime.fromMillisecondsSinceEpoch(0);

  static const _heartbeatInterval = Duration(seconds: 5);
  static const _resyncInterval = Duration(seconds: 4);
  static const _staleCheckInterval = Duration(seconds: 10);
  static const _staleThreshold = Duration(seconds: 60);
  static const _hardSeekPlaying = 1.2; // сек: при большем расхождении — seek
  static const _hardSeekPaused = 0.4; // на паузе кадр должен совпадать точнее
  static const _seekCooldown = Duration(milliseconds: 1500);
  static const _seekLead = 0.25; // компенсация задержки самого seek
  static const _echoSuppress = Duration(milliseconds: 1500);

  SyncController({
    required FirebaseFirestore db,
    required this.roomId,
    required this.myUid,
  }) : _db = db;

  DocumentReference<Map<String, dynamic>> get _roomRef =>
      _db.collection('rooms').doc(roomId);

  DateTime get _serverNow => DateTime.now().add(_serverOffset);

  bool get isAdmin => _isAdmin;
  Room? get room => _room;
  bool get roomMissing => _roomMissing;
  bool get kickedMe => _room?.kicked.contains(myUid) ?? false;
  VideoState? get lastRemote => _remote;

  // ---------------------------------------------------------------- lifecycle

  void start() {
    _calibrateClock();
    _sub = _roomRef.snapshots().listen(
      _onSnapshot,
      onError: (e) => debugPrint('[sync] stream error: $e'),
    );
    _resync = Timer.periodic(_resyncInterval, (_) {
      if (!_isAdmin && _remote != null && _player != null) _applyRemote();
    });
    _staleWatch = Timer.periodic(_staleCheckInterval, (_) => _checkHostAlive());
  }

  @override
  void dispose() {
    _disposed = true;
    _sub?.cancel();
    _heartbeat?.cancel();
    _resync?.cancel();
    _staleWatch?.cancel();
    _player = null;
    super.dispose();
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  /// Плеер вызывает это, когда он ГОТОВ принимать команды.
  void attachPlayer(SyncPlayer player) {
    _player = player;
    if (_remote != null) {
      _suppressUntil = DateTime.now().add(_echoSuppress);
      _applyRemote();
    }
  }

  void detachPlayer(SyncPlayer player) {
    if (identical(_player, player)) _player = null;
  }

  // -------------------------------------------------------------- clock sync

  /// Замеряем сдвиг часов: пишем serverTimestamp в свой members-документ и
  /// читаем его обратно. Ошибка ≤ RTT/2 — для нашей задачи достаточно.
  Future<void> _calibrateClock() async {
    try {
      final ref = _roomRef.collection('members').doc(myUid);
      final t0 = DateTime.now();
      await ref.set({'clockProbe': FieldValue.serverTimestamp()},
          SetOptions(merge: true));
      final snap = await ref.get(const GetOptions(source: Source.server));
      final t1 = DateTime.now();
      final server = (snap.data()?['clockProbe'] as Timestamp?)?.toDate();
      if (server == null) return;
      final mid = t0.add(Duration(microseconds: t1.difference(t0).inMicroseconds ~/ 2));
      _serverOffset = server.difference(mid);
      debugPrint('[sync] clock offset ${_serverOffset.inMilliseconds} ms');
    } catch (e) {
      debugPrint('[sync] calibrate error: $e');
    }
  }

  // ------------------------------------------------------- admin → Firestore

  bool get _canEmit =>
      _isAdmin && DateTime.now().isAfter(_suppressUntil) && _player != null;

  Future<void> onLocalPlay() async {
    if (!_canEmit) return;
    final p = _player!;
    await _writeState(
      position: await p.getCurrentPosition(),
      playing: true,
      duration: await p.getDuration(),
    );
  }

  Future<void> onLocalPause() async {
    if (!_canEmit) return;
    final p = _player!;
    await _writeState(
      position: await p.getCurrentPosition(),
      playing: false,
      duration: await p.getDuration(),
    );
  }

  Future<void> onLocalSeek(double position) async {
    if (!_canEmit) return;
    final p = _player!;
    await _writeState(
      position: position,
      playing: await p.isPlaying(),
      duration: await p.getDuration(),
    );
  }

  /// Явная передача host (например, при выходе из комнаты).
  Future<void> handOverHost(String newHostUid) async {
    if (!_isAdmin) return;
    try {
      await _db.runTransaction((tx) async {
        final snap = await tx.get(_roomRef);
        if (!snap.exists) return;
        if (snap.data()!['hostId'] != myUid) return;
        tx.update(_roomRef, {
          'hostId': newHostUid,
          'hostLastSeen': FieldValue.serverTimestamp(),
          'updatedBy': newHostUid,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      });
    } catch (e) {
      debugPrint('[sync] handover error: $e');
    }
  }

  /// Попытка забрать host, если текущий «мёртв» (>60 с без heartbeat).
  Future<bool> tryTakeOverHost({
    double? currentPosition,
    bool? playing,
    double? duration,
  }) async {
    try {
      return await _db.runTransaction<bool>((tx) async {
        final snap = await tx.get(_roomRef);
        if (!snap.exists) return false;
        final data = snap.data()!;

        if (data['hostId'] == myUid) return true;
        if (List<String>.from(data['kicked'] ?? const []).contains(myUid)) {
          return false;
        }

        final seen = (data['hostLastSeen'] as Timestamp?)?.toDate();
        final isStale =
            seen == null || _serverNow.difference(seen) > _staleThreshold;
        if (!isStale) return false;

        tx.update(_roomRef, {
          'hostId': myUid,
          'hostLastSeen': FieldValue.serverTimestamp(),
          'updatedBy': myUid,
          'updatedAt': FieldValue.serverTimestamp(),
          if (currentPosition != null) 'videoPosition': currentPosition,
          if (playing != null) 'videoPlaying': playing,
          if (duration != null) 'videoDuration': duration,
        });
        return true;
      });
    } catch (e) {
      debugPrint('[sync] takeover error: $e');
      return false;
    }
  }

  /// Зритель периодически проверяет, жив ли хост, и забирает роль.
  /// Случайная задержка снижает число одновременных попыток
  /// (итог всё равно решает транзакция + правила).
  Future<void> _checkHostAlive() async {
    if (_isAdmin || _disposed) return;
    final seen = _hostLastSeen;
    if (seen == null) return;
    if (_serverNow.difference(seen) <= _staleThreshold) return;

    await Future.delayed(Duration(milliseconds: Random().nextInt(3000)));
    if (_disposed || _isAdmin) return;

    final p = _player;
    await tryTakeOverHost(
      currentPosition: p == null ? null : await p.getCurrentPosition(),
      playing: p == null ? null : await p.isPlaying(),
      duration: p == null ? null : await p.getDuration(),
    );
  }

  // -------------------------------------------------------- Firestore → UI

  void _onSnapshot(DocumentSnapshot<Map<String, dynamic>> snap) {
    if (!snap.exists) {
      _roomMissing = true;
      _notify();
      return;
    }
    final data = snap.data()!;
    final room = Room.fromMap(snap.id, data);

    _setAdmin(room.hostId == myUid);

    final seen = (data['hostLastSeen'] as Timestamp?)?.toDate();
    if (seen != null) _hostLastSeen = seen;

    _room = room;
    if (room.signature != _roomSig) {
      _roomSig = room.signature;
      _notify();
    }

    // Локальная запись, ещё не подтверждённая сервером: updatedAt = null.
    if (snap.metadata.hasPendingWrites) return;

    final remote = VideoState.tryParse(data);
    if (remote == null) return;
    _remote = remote;

    if (!_isAdmin) _applyRemote();
  }

  void _setAdmin(bool admin) {
    if (_isAdmin == admin) return;
    _isAdmin = admin;
    if (admin) {
      _startHeartbeat();
    } else {
      _heartbeat?.cancel();
      _heartbeat = null;
    }
    _notify();
  }

  // --------------------------------------------------------- применение state

  Future<void> _applyRemote() async {
    if (_player == null || _remote == null) return;
    if (_applying) {
      _reapply = true; // новый снимок пришёл во время применения — повторим
      return;
    }
    _applying = true;
    try {
      do {
        _reapply = false;
        final p = _player;
        final r = _remote;
        if (p == null || r == null) break;
        await _applyOnce(p, r);
      } while (_reapply && !_disposed);
    } catch (e) {
      debugPrint('[sync] apply error: $e');
    } finally {
      _applying = false;
    }
  }

  Future<void> _applyOnce(SyncPlayer p, VideoState remote) async {
    final target = remote.extrapolatedAt(_serverNow);
    final current = await p.getCurrentPosition();
    final playing = await p.isPlaying();
    final diff = target - current;

    final now = DateTime.now();
    _suppressUntil = now.add(_echoSuppress);

    final limit = remote.playing ? _hardSeekPlaying : _hardSeekPaused;
    final canSeek = now.difference(_lastSeekAt) > _seekCooldown;
    if (diff.abs() > limit && canSeek) {
      _lastSeekAt = now;
      await p.seekTo(remote.playing ? target + _seekLead : target);
    }

    if (remote.playing && !playing) {
      await p.play();
    } else if (!remote.playing && playing) {
      await p.pause();
    }
  }

  // ---------------------------------------------------------------- heartbeat

  void _startHeartbeat() {
    _heartbeat?.cancel();
    _heartbeat = Timer.periodic(_heartbeatInterval, (_) async {
      if (!_isAdmin || _disposed) return;
      final p = _player;
      if (p == null) {
        // Видео ещё не выбрано/не загрузилось, но хост жив.
        try {
          await _roomRef.update({'hostLastSeen': FieldValue.serverTimestamp()});
        } catch (e) {
          debugPrint('[sync] alive error: $e');
        }
        return;
      }
      await _writeState(
        position: await p.getCurrentPosition(),
        playing: await p.isPlaying(),
        duration: await p.getDuration(),
      );
    });
  }

  Future<void> _writeState({
    required double position,
    required bool playing,
    double duration = 0,
  }) async {
    try {
      await _roomRef.update({
        'videoPosition': position,
        'videoPlaying': playing,
        'videoDuration': duration,
        'updatedBy': myUid,
        'updatedAt': FieldValue.serverTimestamp(),
        'hostLastSeen': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      debugPrint('[sync] writeState error: $e');
    }
  }
}
