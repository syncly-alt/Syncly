import '../models/video_source.dart';

/// Общая часть: канал `Bridge` во Flutter и интерполяция времени между
/// событиями плеера. Каждые 500 мс JS шлёт `tick` с текущим состоянием.
const _common = '''
function send(o){ try{ Bridge.postMessage(JSON.stringify(o)); }catch(e){} }
var ready=false, playing=false, time=0, dur=0, tAt=Date.now();
function setTime(t){ time=t; tAt=Date.now(); }
function curTime(){ return time + (playing ? (Date.now()-tAt)/1000 : 0); }
function startTicks(){
  setInterval(function(){
    if(!ready) return;
    send({t:'tick', time:curTime(), dur:dur, playing:playing});
  }, 500);
}
''';

const _head = '''<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>html,body{margin:0;padding:0;height:100%;background:#000;overflow:hidden}
#p,#f{position:absolute;inset:0;width:100%;height:100%;border:0}</style>
</head><body>''';

/// Базовый URL для loadHtmlString. YouTube требует «нормальный» origin,
/// иначе встраивание часто отвечает ошибкой 150/153.
String baseUrlFor(SourceType t) =>
    t == SourceType.youtube ? 'https://www.youtube.com' : 'https://localhost';

String buildEmbedHtml(SourceType type, String id, String hash) {
  switch (type) {
    case SourceType.youtube:
      return _youtube(id);
    case SourceType.vk:
      return _vk(id, hash);
    case SourceType.rutube:
      return _rutube(id);
    case SourceType.drive:
    case SourceType.none:
      return '$_head</body></html>';
  }
}

String _youtube(String videoId) => '''$_head
<div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
$_common
var pl, lastPlaying=false;
function onYouTubeIframeAPIReady(){
  pl = new YT.Player('p', {
    width:'100%', height:'100%', videoId:'$videoId',
    playerVars:{controls:1, playsinline:1, rel:0, modestbranding:1, fs:0, iv_load_policy:3},
    events:{
      onReady:function(){ ready=true; send({t:'ready'}); },
      onStateChange:function(e){
        // 1 playing, 2 paused, 0 ended, 3 buffering (оставляем прежнее намерение)
        if(e.data===1) lastPlaying=true;
        else if(e.data===2 || e.data===0 || e.data===5 || e.data===-1) lastPlaying=false;
      },
      onError:function(e){ send({t:'error', c:'youtube:'+e.data}); }
    }
  });
}
// переопределяем: время/длительность берём прямо из плеера
function curTimeYT(){ return pl && pl.getCurrentTime ? pl.getCurrentTime() : 0; }
setInterval(function(){
  if(!ready || !pl) return;
  send({t:'tick', time:curTimeYT(), dur:(pl.getDuration?pl.getDuration():0)||0, playing:lastPlaying});
}, 500);
function cmd(n,a){
  if(!ready || !pl) return;
  if(n==='play') pl.playVideo();
  else if(n==='pause') pl.pauseVideo();
  else if(n==='seek') pl.seekTo(a, true);
}
</script></body></html>''';

String _vk(String id, String hash) {
  final parts = id.split('_');
  final oid = parts.first;
  final vid = parts.length > 1 ? parts[1] : '';
  final h = hash.isEmpty ? '' : '&hash=$hash';
  final src = 'https://vk.ru/video_ext.php?oid=$oid&id=$vid$h&hd=2&js_api=1';
  return '''$_head
<iframe id="f" src="$src" allow="autoplay; encrypted-media; fullscreen; picture-in-picture" allowfullscreen></iframe>
<script src="https://vk.ru/js/api/videoplayer.js"></script>
<script>
$_common
var pl;
function upd(s){
  if(!s) return;
  if(s.time!=null) setTime(s.time);
  if(s.duration) dur=s.duration;
  if(s.state) playing=(s.state==='playing');
}
window.addEventListener('load', function(){
  try{
    pl = VK.VideoPlayer(document.getElementById('f'));
    pl.on('inited', function(s){ upd(s); ready=true; send({t:'ready'}); startTicks(); });
    ['started','resumed','paused','ended','timeupdate'].forEach(function(n){ pl.on(n, upd); });
    pl.on('error', function(){ send({t:'error', c:'vk'}); });
  }catch(e){ send({t:'error', c:'vk-api'}); }
});
function cmd(n,a){
  if(!ready || !pl) return;
  if(n==='play') pl.play();
  else if(n==='pause') pl.pause();
  else if(n==='seek'){ pl.seek(a); setTime(a); }
}
</script></body></html>''';
}

String _rutube(String id) => '''$_head
<iframe id="f" src="https://rutube.ru/play/embed/$id" allow="clipboard-write; autoplay; fullscreen" allowfullscreen></iframe>
<script>
$_common
var f=document.getElementById('f');
function post(type,data){ try{ f.contentWindow.postMessage(JSON.stringify({type:type,data:data||{}}),'*'); }catch(e){} }
window.addEventListener('message', function(e){
  var m; try{ m = (typeof e.data==='string') ? JSON.parse(e.data) : e.data; }catch(_){ return; }
  if(!m || !m.type) return;
  var d = m.data || {};
  if(m.type==='player:ready'){ ready=true; send({t:'ready'}); startTicks(); }
  else if(m.type==='player:changeState'){ if(d.state==='playing'){ setTime(curTime()); playing=true; } else if(d.state==='paused'||d.state==='stopped'){ setTime(curTime()); playing=false; } }
  else if(m.type==='player:currentTime'){ setTime(d.time); }
  else if(m.type==='player:durationChange'){ dur=d.duration; }
  else if(m.type==='player:error'){ send({t:'error', c:'rutube:'+(d.text||d.code||'')}); }
});
function cmd(n,a){
  if(!ready) return;
  if(n==='play') post('player:play');
  else if(n==='pause') post('player:pause');
  else if(n==='seek'){ post('player:setCurrentTime',{time:a}); setTime(a); }
}
</script></body></html>''';
