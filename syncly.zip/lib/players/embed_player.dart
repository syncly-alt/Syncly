import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:webview_flutter_wkwebview/webview_flutter_wkwebview.dart';

import '../models/room.dart';
import '../models/video_source.dart';
import '../sync/sync_controller.dart';
import 'embed_html.dart';

/// Один класс на все источники: WebView с JS-мостом (см. embed_html.dart).
/// Состояние кэшируется из `tick`-сообщений (каждые 500 мс), поэтому
/// getCurrentPosition()/isPlaying() не делают лишних асинхронных вызовов в JS.
class EmbedPlayerController implements SyncPlayer {
  EmbedPlayerController({
    required this.source,
    required this.videoId,
    this.videoHash = '',
    required this.onReady,
    this.onError,
  }) {
    _init();
  }

  final SourceType source;
  final String videoId;
  final String videoHash;
  final VoidCallback onReady;
  final void Function(String code)? onError;

  /// Действия пользователя внутри плеера (имеют смысл только у админа,
  /// SyncController сам отфильтрует остальное).
  VoidCallback? onUserPlay;
  VoidCallback? onUserPause;
  void Function(double position)? onUserSeek;

  late final WebViewController web;

  bool ready = false;
  bool _firstTick = true;
  double _time = 0;
  double _dur = 0;
  bool _playing = false;
  DateTime _at = DateTime.now();

  void _init() {
    late final PlatformWebViewControllerCreationParams params;
    if (WebViewPlatform.instance is WebKitWebViewPlatform) {
      params = WebKitWebViewControllerCreationParams(
        allowsInlineMediaPlayback: true,
        mediaTypesRequiringUserAction: const <PlaybackMediaTypes>{},
      );
    } else {
      params = const PlatformWebViewControllerCreationParams();
    }

    final base = baseUrlFor(source);
    web = WebViewController.fromPlatformCreationParams(params)
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..addJavaScriptChannel('Bridge',
          onMessageReceived: (m) => _onMessage(m.message))
      ..setNavigationDelegate(NavigationDelegate(
        // Главный фрейм никуда не уходит; рекламные переходы внутри iframe
        // (isMainFrame == false) не трогаем.
        onNavigationRequest: (r) {
          if (!r.isMainFrame) return NavigationDecision.navigate;
          final ok = r.url.startsWith(base) || r.url.startsWith('about:');
          return ok ? NavigationDecision.navigate : NavigationDecision.prevent;
        },
      ));

    final platform = web.platform;
    if (platform is AndroidWebViewController) {
      platform.setMediaPlaybackRequiresUserGesture(false);
    }

    web.loadHtmlString(buildEmbedHtml(source, videoId, videoHash), baseUrl: base);
  }

  void _onMessage(String raw) {
    Map<String, dynamic> m;
    try {
      m = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    switch (m['t']) {
      case 'ready':
        if (!ready) {
          ready = true;
          onReady();
        }
        break;
      case 'error':
        onError?.call('${m['c']}');
        break;
      case 'tick':
        _onTick(
          (m['time'] as num?)?.toDouble() ?? 0,
          (m['dur'] as num?)?.toDouble() ?? 0,
          m['playing'] == true,
        );
        break;
    }
  }

  void _onTick(double time, double dur, bool playing) {
    final now = DateTime.now();
    VoidCallback? fire;
    double? seekTo;

    if (!_firstTick) {
      if (playing != _playing) {
        fire = playing ? onUserPlay : onUserPause;
      }
      final expected =
          _time + (_playing ? now.difference(_at).inMilliseconds / 1000.0 : 0);
      if ((time - expected).abs() > 2.0) seekTo = time;
    }
    _firstTick = false;

    // Сначала обновляем кэш, потом дёргаем колбэки (они читают позицию).
    _time = time;
    _dur = dur;
    _playing = playing;
    _at = now;

    if (seekTo != null) onUserSeek?.call(seekTo);
    fire?.call();
  }

  Future<void> _run(String js) async {
    try {
      await web.runJavaScript(js);
    } catch (e) {
      debugPrint('[player] js error: $e');
    }
  }

  // ------------------------------------------------------------ SyncPlayer

  @override
  Future<void> play() async {
    _time = await getCurrentPosition();
    _playing = true; // оптимистично: не считаем это действием пользователя
    _at = DateTime.now();
    await _run("cmd('play')");
  }

  @override
  Future<void> pause() async {
    _time = await getCurrentPosition();
    _playing = false;
    _at = DateTime.now();
    await _run("cmd('pause')");
  }

  @override
  Future<void> seekTo(double seconds) async {
    _time = seconds;
    _at = DateTime.now();
    await _run("cmd('seek', ${seconds.toStringAsFixed(2)})");
  }

  @override
  Future<double> getCurrentPosition() async {
    var t = _time;
    if (_playing) t += DateTime.now().difference(_at).inMilliseconds / 1000.0;
    if (_dur > 0 && t > _dur) t = _dur;
    return t < 0 ? 0 : t;
  }

  @override
  Future<bool> isPlaying() async => _playing;

  @override
  Future<double> getDuration() async => _dur;
}

/// Виджет плеера. Пересоздаётся (через ValueKey(room.videoKey)) при смене видео.
class EmbedPlayerView extends StatefulWidget {
  const EmbedPlayerView({
    super.key,
    required this.room,
    required this.sync,
    required this.isAdmin,
  });

  final Room room;
  final SyncController sync;
  final bool isAdmin;

  @override
  State<EmbedPlayerView> createState() => _EmbedPlayerViewState();
}

class _EmbedPlayerViewState extends State<EmbedPlayerView> {
  late final EmbedPlayerController _c;
  bool _ready = false;
  String? _error;
  Timer? _timeout;

  @override
  void initState() {
    super.initState();
    _c = EmbedPlayerController(
      source: widget.room.source,
      videoId: widget.room.videoId,
      videoHash: widget.room.videoHash,
      onReady: _onReady,
      onError: (e) {
        if (mounted) setState(() => _error = _humanError(e));
      },
    )
      ..onUserPlay = widget.sync.onLocalPlay
      ..onUserPause = widget.sync.onLocalPause
      ..onUserSeek = widget.sync.onLocalSeek;

    _timeout = Timer(const Duration(seconds: 25), () {
      if (mounted && !_ready && _error == null) {
        setState(() => _error =
            'Плеер не загрузился. Проверьте интернет или ссылку на видео.');
      }
    });
  }

  void _onReady() {
    if (!mounted) return;
    setState(() => _ready = true);
    widget.sync.attachPlayer(_c);
  }

  String _humanError(String code) {
    if (code.startsWith('youtube:')) {
      final n = code.substring(8);
      if (n == '101' || n == '150' || n == '153') {
        return 'Автор запретил встраивание этого видео. Выберите другое.';
      }
      if (n == '100') return 'Видео удалено или закрыто.';
      return 'Ошибка YouTube ($n)';
    }
    if (code == 'vk-api') {
      return 'VK-плеер не отвечает. Для приватных видео нужна ссылка с hash.';
    }
    return 'Ошибка плеера: $code';
  }

  @override
  void dispose() {
    _timeout?.cancel();
    widget.sync.detachPlayer(_c);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 16 / 9,
      child: Stack(
        fit: StackFit.expand,
        children: [
          WebViewWidget(controller: _c.web),
          if (!_ready && _error == null)
            const ColoredBox(
              color: Colors.black,
              child: Center(child: CircularProgressIndicator()),
            ),
          if (_error != null)
            ColoredBox(
              color: Colors.black87,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Center(
                  child: Text(_error!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white70)),
                ),
              ),
            ),
          // Зрители не управляют плеером: перехватываем касания.
          if (!widget.isAdmin)
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {},
                child: const Align(
                  alignment: Alignment.bottomLeft,
                  child: Padding(
                    padding: EdgeInsets.all(8),
                    child: _ViewerBadge(),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _ViewerBadge extends StatelessWidget {
  const _ViewerBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.black54,
        borderRadius: BorderRadius.circular(10),
      ),
      child: const Text('Управляет админ',
          style: TextStyle(color: Colors.white70, fontSize: 11)),
    );
  }
}
