import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';

class _Job {
  final Uint8List bytes;
  final int size;
  final bool png;
  const _Job(this.bytes, this.size, this.png);
}

/// Тяжёлая часть — в отдельном изоляте, чтобы не фризить UI.
Uint8List? _process(_Job job) {
  final decoded = img.decodeImage(job.bytes);
  if (decoded == null) return null;
  final square = img.copyResizeCropSquare(decoded, size: job.size);
  return job.png
      ? Uint8List.fromList(img.encodePng(square))
      : Uint8List.fromList(img.encodeJpg(square, quality: 82));
}

class ImageUtils {
  /// Выбор картинки из галереи → квадрат [size]×[size] → base64.
  /// Аватар: JPEG 160px (~8 КБ). Эмодзи: PNG 96px с прозрачностью.
  static Future<String?> pickSquareBase64({
    required int size,
    required bool png,
  }) async {
    final file = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 1200,
      maxHeight: 1200,
    );
    if (file == null) return null;
    final bytes = await file.readAsBytes();
    final out = await compute(_process, _Job(bytes, size, png));
    if (out == null) return null;
    return base64Encode(out);
  }
}
