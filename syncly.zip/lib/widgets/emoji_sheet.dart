import 'package:flutter/material.dart';

import '../models/room.dart';
import '../services/emoji_service.dart';
import 'avatar_view.dart';

/// Лист с личными эмодзи.
/// [onPick] != null → режим выбора (чат): тап отправляет эмодзи.
/// [onPick] == null → режим управления (главный экран).
class EmojiSheet extends StatelessWidget {
  const EmojiSheet({super.key, this.onPick});

  final void Function(CustomEmoji emoji)? onPick;

  static Future<void> show(BuildContext context,
      {void Function(CustomEmoji emoji)? onPick}) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => EmojiSheet(onPick: onPick),
    );
  }

  Future<void> _add(BuildContext context, int count) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await EmojiService.instance.addFromGallery(currentCount: count);
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Future<void> _confirmDelete(BuildContext context, CustomEmoji e) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить эмодзи?'),
        content: EmojiImage(b64: e.b64, size: 72),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Отмена')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Удалить')),
        ],
      ),
    );
    if (ok == true) await EmojiService.instance.remove(e.id);
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return SizedBox(
      height: h * 0.55,
      child: StreamBuilder<List<CustomEmoji>>(
        stream: EmojiService.instance.watch(),
        builder: (context, snap) {
          final list = snap.data ?? const <CustomEmoji>[];
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        onPick == null ? 'Мои эмодзи' : 'Отправить эмодзи',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    ),
                    Text('${list.length}/${EmojiService.maxEmojis}',
                        style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 80,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                  ),
                  itemCount: list.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) {
                      return InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => _add(context, list.length),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                                color: Theme.of(context).colorScheme.outline),
                          ),
                          child: const Icon(Icons.add_photo_alternate_outlined),
                        ),
                      );
                    }
                    final e = list[i - 1];
                    return InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: onPick == null
                          ? null
                          : () {
                              Navigator.pop(context);
                              onPick!(e);
                            },
                      onLongPress: () => _confirmDelete(context, e),
                      child: Padding(
                        padding: const EdgeInsets.all(4),
                        child: EmojiImage(b64: e.b64, size: 64),
                      ),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text('Нажмите «+», чтобы добавить картинку. Долгое нажатие — удалить.',
                    style: Theme.of(context).textTheme.bodySmall),
              ),
            ],
          );
        },
      ),
    );
  }
}
