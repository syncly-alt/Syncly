import 'package:flutter/material.dart';

import '../models/room.dart';
import '../services/auth_service.dart';
import 'avatar_view.dart';

class MembersPanel extends StatelessWidget {
  const MembersPanel({
    super.key,
    required this.members,
    required this.hostId,
    required this.isAdmin,
    required this.onKick,
    required this.onMakeHost,
  });

  final List<Member> members;
  final String hostId;
  final bool isAdmin;
  final void Function(Member m) onKick;
  final void Function(Member m) onMakeHost;

  @override
  Widget build(BuildContext context) {
    final me = AuthService.instance.uid;
    if (members.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    return ListView.builder(
      itemCount: members.length,
      itemBuilder: (context, i) {
        final m = members[i];
        final isHost = m.uid == hostId;
        return ListTile(
          leading: Stack(
            clipBehavior: Clip.none,
            children: [
              AvatarView(nick: m.nick, b64: m.avatarB64, radius: 20),
              Positioned(
                right: -1,
                bottom: -1,
                child: Container(
                  width: 11,
                  height: 11,
                  decoration: BoxDecoration(
                    color: m.online ? Colors.greenAccent.shade400 : Colors.grey,
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: Theme.of(context).scaffoldBackgroundColor,
                        width: 2),
                  ),
                ),
              ),
            ],
          ),
          title: Row(
            children: [
              Flexible(child: Text(m.nick, overflow: TextOverflow.ellipsis)),
              if (m.uid == me)
                Text('  (вы)', style: Theme.of(context).textTheme.bodySmall),
              if (isHost)
                const Padding(
                  padding: EdgeInsets.only(left: 6),
                  child: Icon(Icons.workspace_premium_rounded,
                      size: 18, color: Colors.amber),
                ),
            ],
          ),
          subtitle: Text(isHost ? 'Админ' : (m.online ? 'В сети' : 'Не в сети')),
          trailing: (isAdmin && m.uid != me)
              ? PopupMenuButton<String>(
                  onSelected: (v) => v == 'kick' ? onKick(m) : onMakeHost(m),
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'host', child: Text('Сделать админом')),
                    PopupMenuItem(value: 'kick', child: Text('Исключить')),
                  ],
                )
              : null,
        );
      },
    );
  }
}
