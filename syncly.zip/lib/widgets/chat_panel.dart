import 'package:flutter/material.dart';

import '../models/room.dart';
import '../services/auth_service.dart';
import '../services/room_service.dart';
import 'avatar_view.dart';
import 'emoji_sheet.dart';

class ChatPanel extends StatefulWidget {
  const ChatPanel({
    super.key,
    required this.code,
    required this.myNick,
    required this.members,
  });

  final String code;
  final String myNick;
  final List<Member> members;

  @override
  State<ChatPanel> createState() => _ChatPanelState();
}

class _ChatPanelState extends State<ChatPanel> {
  final _controller = TextEditingController();
  late final Stream<List<ChatMessage>> _stream;

  @override
  void initState() {
    super.initState();
    _stream = RoomService.instance.watchMessages(widget.code);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _controller.text;
    if (text.trim().isEmpty) return;
    _controller.clear();
    try {
      await RoomService.instance.sendText(widget.code, widget.myNick, text);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Не удалось отправить')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final myUid = AuthService.instance.uid;
    final byUid = {for (final m in widget.members) m.uid: m};

    return Column(
      children: [
        Expanded(
          child: StreamBuilder<List<ChatMessage>>(
            stream: _stream,
            builder: (context, snap) {
              final msgs = snap.data ?? const <ChatMessage>[];
              if (msgs.isEmpty) {
                return Center(
                  child: Text('Пока тихо. Напишите первым!',
                      style: Theme.of(context).textTheme.bodyMedium),
                );
              }
              return ListView.builder(
                reverse: true, // новые сообщения внизу
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                itemCount: msgs.length,
                itemBuilder: (context, i) {
                  final m = msgs[i];
                  final mine = m.userId == myUid;
                  final member = byUid[m.userId];
                  return _Bubble(
                    msg: m,
                    mine: mine,
                    avatarB64: member?.avatarB64,
                  );
                },
              );
            },
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
            child: Row(
              children: [
                IconButton(
                  tooltip: 'Эмодзи',
                  icon: const Icon(Icons.emoji_emotions_outlined),
                  onPressed: () => EmojiSheet.show(context, onPick: (e) {
                    RoomService.instance
                        .sendEmoji(widget.code, widget.myNick, e.b64);
                  }),
                ),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    maxLength: 500,
                    minLines: 1,
                    maxLines: 3,
                    textCapitalization: TextCapitalization.sentences,
                    onSubmitted: (_) => _send(),
                    decoration: const InputDecoration(
                      hintText: 'Сообщение…',
                      counterText: '',
                      isDense: true,
                    ),
                  ),
                ),
                IconButton.filled(
                  icon: const Icon(Icons.send_rounded),
                  onPressed: _send,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.msg, required this.mine, this.avatarB64});

  final ChatMessage msg;
  final bool mine;
  final String? avatarB64;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isEmoji = msg.type == 'emoji' && msg.emojiB64 != null;

    final body = isEmoji
        ? EmojiImage(b64: msg.emojiB64!, size: 72)
        : Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: mine ? scheme.primary : scheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              msg.text,
              style: TextStyle(
                  color: mine ? scheme.onPrimary : scheme.onSurface),
            ),
          );

    final column = Column(
      crossAxisAlignment:
          mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        if (!mine)
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 2),
            child: Text(msg.nick,
                style: Theme.of(context)
                    .textTheme
                    .labelSmall
                    ?.copyWith(color: scheme.onSurfaceVariant)),
          ),
        body,
      ],
    );

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment:
            mine ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!mine) ...[
            AvatarView(nick: msg.nick, b64: avatarB64, radius: 14),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: ConstrainedBox(
              constraints: BoxConstraints(
                  maxWidth: MediaQuery.of(context).size.width * 0.75),
              child: column,
            ),
          ),
        ],
      ),
    );
  }
}
