import 'dart:collection';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';

/// Кэш декодированных base64-картинок, чтобы не декодировать на каждый build.
class B64Cache {
  static final _map = LinkedHashMap<String, Uint8List>();
  static const _max = 300;

  static Uint8List? get(String? b64) {
    if (b64 == null || b64.isEmpty) return null;
    final hit = _map.remove(b64);
    if (hit != null) {
      _map[b64] = hit;
      return hit;
    }
    try {
      final bytes = base64Decode(b64);
      _map[b64] = bytes;
      if (_map.length > _max) _map.remove(_map.keys.first);
      return bytes;
    } catch (_) {
      return null;
    }
  }
}

class AvatarView extends StatelessWidget {
  const AvatarView({
    super.key,
    required this.nick,
    this.b64,
    this.radius = 18,
  });

  final String nick;
  final String? b64;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final bytes = B64Cache.get(b64);
    final scheme = Theme.of(context).colorScheme;
    if (bytes != null) {
      return CircleAvatar(
        radius: radius,
        backgroundColor: scheme.surfaceContainerHighest,
        backgroundImage: MemoryImage(bytes),
      );
    }
    final letter = nick.trim().isEmpty ? '?' : nick.trim()[0].toUpperCase();
    return CircleAvatar(
      radius: radius,
      backgroundColor: scheme.primaryContainer,
      child: Text(letter,
          style: TextStyle(
              fontSize: radius * 0.9,
              fontWeight: FontWeight.w600,
              color: scheme.onPrimaryContainer)),
    );
  }
}

/// Картинка-эмодзи (кастомная).
class EmojiImage extends StatelessWidget {
  const EmojiImage({super.key, required this.b64, this.size = 64});
  final String b64;
  final double size;

  @override
  Widget build(BuildContext context) {
    final bytes = B64Cache.get(b64);
    if (bytes == null) return SizedBox(width: size, height: size);
    return Image.memory(bytes,
        width: size, height: size, gaplessPlayback: true, filterQuality: FilterQuality.medium);
  }
}
