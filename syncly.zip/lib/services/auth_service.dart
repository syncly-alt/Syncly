import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/room.dart';

/// Анонимный вход + профиль (ник, аватар) в `users/{uid}`.
/// Профиль живёт, пока не удалили приложение; для переноса между устройствами
/// позже можно привязать e-mail/Google через `linkWithCredential`.
class AuthService {
  AuthService._();
  static final instance = AuthService._();

  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;

  Stream<User?> get authChanges => _auth.authStateChanges();
  User? get user => _auth.currentUser;
  String get uid => _auth.currentUser!.uid;

  Stream<AppUser?> watchProfile(String uid) =>
      _db.collection('users').doc(uid).snapshots().map(
            (s) => s.exists ? AppUser.fromDoc(uid, s.data()!) : null,
          );

  Future<AppUser?> loadProfile() async {
    final u = _auth.currentUser;
    if (u == null) return null;
    final s = await _db.collection('users').doc(u.uid).get();
    return s.exists ? AppUser.fromDoc(u.uid, s.data()!) : null;
  }

  /// Создаёт/обновляет профиль. При первом вызове выполняет анонимный вход.
  Future<void> saveProfile({required String nick, String? avatarB64}) async {
    final u = _auth.currentUser ?? (await _auth.signInAnonymously()).user!;
    final ref = _db.collection('users').doc(u.uid);
    final exists = (await ref.get()).exists;
    await ref.set({
      'nick': nick.trim(),
      if (avatarB64 != null) 'avatarB64': avatarB64,
      if (!exists) 'premium': false, // менять premium с клиента запрещено правилами
      if (!exists) 'createdAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }
}
