import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/room.dart';
import '../models/video_source.dart';
import 'auth_service.dart';

class RoomException implements Exception {
  final String message;
  RoomException(this.message);
  @override
  String toString() => message;
}

class RoomService {
  RoomService._();
  static final instance = RoomService._();

  final _db = FirebaseFirestore.instance;

  // Без похожих символов (0/O, 1/I).
  static const _alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  static final codePattern = RegExp(r'^[A-HJ-NP-Z2-9]{6}$');

  static String normalizeCode(String raw) =>
      raw.trim().toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

  String _newCode() {
    final r = Random.secure();
    return List.generate(6, (_) => _alphabet[r.nextInt(_alphabet.length)]).join();
  }

  DocumentReference<Map<String, dynamic>> _room(String code) =>
      _db.collection('rooms').doc(code);

  // --------------------------------------------------------------- создание

  Future<String> createRoom(String name) async {
    final uid = AuthService.instance.uid;
    for (var attempt = 0; attempt < 5; attempt++) {
      final code = _newCode();
      final ref = _room(code);
      try {
        final created = await _db.runTransaction<bool>((tx) async {
          if ((await tx.get(ref)).exists) return false;
          tx.set(ref, {
            'code': code,
            'name': name.trim().isEmpty ? 'Комната' : name.trim(),
            'hostId': uid,
            'hostLastSeen': FieldValue.serverTimestamp(),
            'updatedAt': FieldValue.serverTimestamp(),
            'updatedBy': uid,
            'videoPosition': 0.0,
            'videoPlaying': false,
            'videoDuration': 0.0,
            'sourceType': SourceType.none.id,
            'videoId': '',
            'videoHash': '',
            'videoUrl': '',
            'kicked': <String>[],
            'createdAt': FieldValue.serverTimestamp(),
          });
          return true;
        });
        if (created) {
          await joinRoom(code);
          return code;
        }
      } on FirebaseException catch (e) {
        throw RoomException('Не удалось создать комнату: ${e.message ?? e.code}');
      }
    }
    throw RoomException('Не удалось подобрать код комнаты, попробуйте ещё раз');
  }

  // ------------------------------------------------------------------ вход

  Future<Room> joinRoom(String rawCode) async {
    final code = normalizeCode(rawCode);
    if (!codePattern.hasMatch(code)) {
      throw RoomException('Код комнаты — 6 символов (буквы A–Z и цифры)');
    }
    final uid = AuthService.instance.uid;
    final snap = await _room(code).get();
    if (!snap.exists) throw RoomException('Комната $code не найдена');
    final room = Room.fromMap(code, snap.data()!);
    if (room.kicked.contains(uid)) {
      throw RoomException('Админ исключил вас из этой комнаты');
    }

    final profile = await AuthService.instance.loadProfile();
    final memberRef = _room(code).collection('members').doc(uid);
    final existing = await memberRef.get();
    await memberRef.set({
      'nick': profile?.nick ?? 'Гость',
      if (profile?.avatarB64 != null) 'avatarB64': profile!.avatarB64,
      if (!existing.exists) 'joinedAt': FieldValue.serverTimestamp(),
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    return room;
  }

  /// Обновляет «я здесь» (вызывается раз в ~30 с).
  Future<void> touch(String code) async {
    try {
      await _room(code)
          .collection('members')
          .doc(AuthService.instance.uid)
          .update({'lastSeen': FieldValue.serverTimestamp()});
    } catch (_) {}
  }

  Future<void> leave(String code) async {
    try {
      await _room(code)
          .collection('members')
          .doc(AuthService.instance.uid)
          .delete();
    } catch (_) {}
  }

  // ------------------------------------------------------------ участники

  Stream<List<Member>> watchMembers(String code) => _room(code)
      .collection('members')
      .snapshots()
      .map((s) => s.docs.map((d) => Member.fromDoc(d.id, d.data())).toList()
        ..sort((a, b) => (a.joinedAt ?? DateTime.now())
            .compareTo(b.joinedAt ?? DateTime.now())));

  Future<void> kick(String code, String uid) async {
    final batch = _db.batch();
    batch.update(_room(code), {
      'kicked': FieldValue.arrayUnion([uid]),
    });
    batch.delete(_room(code).collection('members').doc(uid));
    await batch.commit();
  }

  // ----------------------------------------------------------------- видео

  /// Только админ (правила Firestore это тоже проверяют).
  Future<void> setVideo(String code, ParsedVideo v) async {
    final uid = AuthService.instance.uid;
    await _room(code).update({
      'sourceType': v.type.id,
      'videoId': v.id,
      'videoHash': v.hash,
      'videoUrl': v.url,
      'videoPosition': 0.0,
      'videoPlaying': false,
      'videoDuration': 0.0,
      'updatedBy': uid,
      'updatedAt': FieldValue.serverTimestamp(),
      'hostLastSeen': FieldValue.serverTimestamp(),
    });
  }

  // ------------------------------------------------------------------ чат

  Stream<List<ChatMessage>> watchMessages(String code) => _room(code)
      .collection('messages')
      .orderBy('createdAt', descending: true)
      .limit(100)
      .snapshots()
      .map((s) =>
          s.docs.map((d) => ChatMessage.fromDoc(d.id, d.data())).toList());

  Future<void> sendText(String code, String nick, String text) async {
    final t = text.trim();
    if (t.isEmpty) return;
    await _room(code).collection('messages').add({
      'userId': AuthService.instance.uid,
      'nick': nick,
      'type': 'text',
      'text': t.length > 500 ? t.substring(0, 500) : t,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> sendEmoji(String code, String nick, String emojiB64) async {
    await _room(code).collection('messages').add({
      'userId': AuthService.instance.uid,
      'nick': nick,
      'type': 'emoji',
      'text': '',
      'emojiB64': emojiB64,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}
