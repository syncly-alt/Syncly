import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/room.dart';
import '../utils/image_utils.dart';
import 'auth_service.dart';

/// Личная библиотека кастомных эмодзи: `users/{uid}/emojis/{id}`.
/// Эмодзи — это картинка 96×96 PNG; при отправке в чат картинка
/// копируется прямо в сообщение, поэтому её увидят все участники.
class EmojiService {
  EmojiService._();
  static final instance = EmojiService._();

  static const maxEmojis = 60;

  CollectionReference<Map<String, dynamic>> get _col => FirebaseFirestore
      .instance
      .collection('users')
      .doc(AuthService.instance.uid)
      .collection('emojis');

  Stream<List<CustomEmoji>> watch() => _col
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((s) => s.docs
          .where((d) => d.data()['b64'] is String)
          .map((d) => CustomEmoji(d.id, d.data()['b64'] as String))
          .toList());

  /// Возвращает false, если пользователь отменил выбор.
  Future<bool> addFromGallery({required int currentCount}) async {
    if (currentCount >= maxEmojis) {
      throw StateError('Максимум $maxEmojis эмодзи');
    }
    final b64 = await ImageUtils.pickSquareBase64(size: 96, png: true);
    if (b64 == null) return false;
    await _col.add({'b64': b64, 'createdAt': FieldValue.serverTimestamp()});
    return true;
  }

  Future<void> remove(String id) => _col.doc(id).delete();
}
