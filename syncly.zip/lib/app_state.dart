import 'package:flutter/material.dart';

import 'services/room_service.dart';

final navigatorKey = GlobalKey<NavigatorState>();

/// Код комнаты из приглашения (deep link). HomeScreen подхватывает его
/// и входит в комнату, как только пользователь авторизован.
final pendingInvite = ValueNotifier<String?>(null);

/// `syncly://room/ABC123`, `https://example.com/r/ABC123`, `...?code=ABC123`.
String? roomCodeFromUri(Uri uri) {
  final candidates = <String?>[
    uri.queryParameters['code'],
    ...uri.pathSegments.reversed,
    uri.host,
  ];
  for (final c in candidates) {
    if (c == null) continue;
    final n = RoomService.normalizeCode(c);
    if (RoomService.codePattern.hasMatch(n)) return n;
  }
  return null;
}
