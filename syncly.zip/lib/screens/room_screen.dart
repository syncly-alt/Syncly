import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../models/room.dart';
import '../players/embed_player.dart';
import '../services/auth_service.dart';
import '../services/room_service.dart';
import '../sync/sync_controller.dart';
import '../widgets/chat_panel.dart';
import '../widgets/members_panel.dart';
import 'video_picker_sheet.dart';

class RoomScreen extends StatefulWidget {
  const RoomScreen({super.key, required this.code});
  final String code;

  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

class _RoomScreenState extends State<RoomScreen> {
  late final SyncController _sync;
  late final String _myUid;
  Timer? _presence;
  StreamSubscription<List<Member>>? _membersSub;

  List<Member> _members = const [];
  AppUser? _me;
  bool _closing = false;

  @override
  void initState() {
    super.initState();
    _myUid = AuthService.instance.uid;

    _sync = SyncController(
      db: FirebaseFirestore.instance,
      roomId: widget.code,
      myUid: _myUid,
    )
      ..addListener(_onSync)
      ..start();

    _membersSub = RoomService.instance
        .watchMembers(widget.code)
        .listen((m) => mounted ? setState(() => _members = m) : null);

    _presence = Timer.periodic(const Duration(seconds: 30),
        (_) => RoomService.instance.touch(widget.code));

    AuthService.instance.loadProfile().then((p) {
      if (mounted) setState(() => _me = p);
    });
  }

  void _onSync() {
    if (_closing || !mounted) return;
    if (_sync.kickedMe) {
      _closeWith('Админ исключил вас из комнаты');
    } else if (_sync.roomMissing) {
      _closeWith('Комната больше не существует');
    }
  }

  void _closeWith(String message) {
    _closing = true;
    final messenger = ScaffoldMessenger.of(context);
    Navigator.of(context).pop();
    messenger.showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  void dispose() {
    _presence?.cancel();
    _membersSub?.cancel();

    // Админ уходит → передаём роль самому «старому» из онлайн-участников.
    if (_sync.isAdmin) {
      final candidates =
          _members.where((m) => m.uid != _myUid && m.online).toList();
      if (candidates.isNotEmpty) {
        unawaited(_sync.handOverHost(candidates.first.uid));
      }
    }
    unawaited(RoomService.instance.leave(widget.code));

    _sync.removeListener(_onSync);
    _sync.dispose();
    super.dispose();
  }

  // ------------------------------------------------------------- действия

  String get _inviteText =>
      'Го смотреть вместе в Syncly! Код комнаты: ${widget.code}\n'
      'Ссылка: syncly://room/${widget.code}';

  Future<void> _share() async {
    await Share.share(_inviteText);
  }

  Future<void> _copyCode() async {
    await Clipboard.setData(ClipboardData(text: widget.code));
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(const SnackBar(content: Text('Код скопирован')));
  }

  Future<void> _kick(Member m) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Исключить ${m.nick}?'),
        content: const Text('Он не сможет вернуться в эту комнату.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Отмена')),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Исключить'),
          ),
        ],
      ),
    );
    if (ok == true) {
      try {
        await RoomService.instance.kick(widget.code, m.uid);
      } catch (e) {
        _toast('Не удалось исключить: $e');
      }
    }
  }

  Future<void> _makeHost(Member m) async {
    await _sync.handOverHost(m.uid);
  }

  void _toast(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  // ------------------------------------------------------------------ UI

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _sync,
      builder: (context, _) {
        final room = _sync.room;
        final isAdmin = _sync.isAdmin;
        final theme = Theme.of(context);

        return Scaffold(
          appBar: AppBar(
            titleSpacing: 0,
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(room?.name ?? 'Комната',
                    style: theme.textTheme.titleMedium,
                    overflow: TextOverflow.ellipsis),
                GestureDetector(
                  onTap: _copyCode,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(widget.code,
                          style: theme.textTheme.bodySmall?.copyWith(
                              letterSpacing: 2,
                              color: theme.colorScheme.primary)),
                      const SizedBox(width: 4),
                      Icon(Icons.copy_rounded,
                          size: 12, color: theme.colorScheme.primary),
                    ],
                  ),
                ),
              ],
            ),
            actions: [
              if (isAdmin)
                IconButton(
                  tooltip: 'Выбрать видео',
                  icon: const Icon(Icons.video_library_outlined),
                  onPressed: () => VideoPickerSheet.show(context,
                      code: widget.code, premium: _me?.premium ?? false),
                ),
              IconButton(
                tooltip: 'Пригласить',
                icon: const Icon(Icons.ios_share_rounded),
                onPressed: _share,
              ),
            ],
          ),
          body: Column(
            children: [
              _buildPlayer(room, isAdmin),
              Expanded(
                child: DefaultTabController(
                  length: 2,
                  child: Column(
                    children: [
                      TabBar(
                        tabs: [
                          const Tab(text: 'Чат'),
                          Tab(text: 'Участники (${_members.length})'),
                        ],
                      ),
                      Expanded(
                        child: TabBarView(
                          children: [
                            ChatPanel(
                              code: widget.code,
                              myNick: _me?.nick ?? 'Гость',
                              members: _members,
                            ),
                            MembersPanel(
                              members: _members,
                              hostId: room?.hostId ?? '',
                              isAdmin: isAdmin,
                              onKick: _kick,
                              onMakeHost: _makeHost,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPlayer(Room? room, bool isAdmin) {
    if (room == null) {
      return const AspectRatio(
        aspectRatio: 16 / 9,
        child: ColoredBox(
          color: Colors.black,
          child: Center(child: CircularProgressIndicator()),
        ),
      );
    }
    if (!room.hasVideo) {
      return AspectRatio(
        aspectRatio: 16 / 9,
        child: ColoredBox(
          color: const Color(0xFF14141B),
          child: Center(
            child: isAdmin
                ? FilledButton.icon(
                    style: FilledButton.styleFrom(
                        minimumSize: const Size(220, 48)),
                    onPressed: () => VideoPickerSheet.show(context,
                        code: widget.code, premium: _me?.premium ?? false),
                    icon: const Icon(Icons.play_circle_outline),
                    label: const Text('Выбрать видео'),
                  )
                : Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      'Админ ещё не выбрал видео.\nПоделитесь кодом комнаты с друзьями!',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),
          ),
        ),
      );
    }
    return EmbedPlayerView(
      key: ValueKey(room.videoKey),
      room: room,
      sync: _sync,
      isAdmin: isAdmin,
    );
  }
}
