import 'package:flutter/material.dart';

import '../services/auth_service.dart';
import '../utils/image_utils.dart';
import '../widgets/avatar_view.dart';

/// Регистрация (firstTime) и редактирование профиля: ник + аватар.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key, this.firstTime = false, this.initialNick, this.initialAvatar});

  final bool firstTime;
  final String? initialNick;
  final String? initialAvatar;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late final TextEditingController _nick;
  String? _avatar;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _nick = TextEditingController(text: widget.initialNick ?? '');
    _avatar = widget.initialAvatar;
  }

  @override
  void dispose() {
    _nick.dispose();
    super.dispose();
  }

  Future<void> _pickAvatar() async {
    try {
      final b64 = await ImageUtils.pickSquareBase64(size: 160, png: false);
      if (b64 != null && mounted) setState(() => _avatar = b64);
    } catch (_) {
      if (mounted) setState(() => _error = 'Не удалось открыть картинку');
    }
  }

  Future<void> _save() async {
    final nick = _nick.text.trim();
    if (nick.length < 2 || nick.length > 24) {
      setState(() => _error = 'Ник — от 2 до 24 символов');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await AuthService.instance.saveProfile(nick: nick, avatarB64: _avatar);
      if (!widget.firstTime && mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        setState(() {
          _busy = false;
          _error = 'Не удалось сохранить: $e';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: widget.firstTime
          ? null
          : AppBar(title: const Text('Профиль')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            if (widget.firstTime) ...[
              const SizedBox(height: 24),
              Text('Syncly',
                  style: theme.textTheme.displaySmall
                      ?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text('Смотрите видео вместе, где бы вы ни были.',
                  style: theme.textTheme.bodyLarge
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
              const SizedBox(height: 40),
            ],
            Center(
              child: GestureDetector(
                onTap: _busy ? null : _pickAvatar,
                child: Stack(
                  children: [
                    AvatarView(
                        nick: _nick.text, b64: _avatar, radius: 56),
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: CircleAvatar(
                        radius: 18,
                        backgroundColor: theme.colorScheme.primary,
                        child: Icon(Icons.photo_camera_outlined,
                            size: 18, color: theme.colorScheme.onPrimary),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 28),
            TextField(
              controller: _nick,
              maxLength: 24,
              enabled: !_busy,
              textCapitalization: TextCapitalization.words,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(labelText: 'Ник'),
            ),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 4, bottom: 8),
                child: Text(_error!,
                    style: TextStyle(color: theme.colorScheme.error)),
              ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: _busy ? null : _save,
              child: _busy
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : Text(widget.firstTime ? 'Начать' : 'Сохранить'),
            ),
          ],
        ),
      ),
    );
  }
}
