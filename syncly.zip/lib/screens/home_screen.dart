import 'package:flutter/material.dart';

import '../app_state.dart';
import '../models/room.dart';
import '../services/room_service.dart';
import '../widgets/avatar_view.dart';
import '../widgets/emoji_sheet.dart';
import 'profile_screen.dart';
import 'room_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.me});
  final AppUser me;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _code = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    pendingInvite.addListener(_consumeInvite);
    WidgetsBinding.instance.addPostFrameCallback((_) => _consumeInvite());
  }

  @override
  void dispose() {
    pendingInvite.removeListener(_consumeInvite);
    _code.dispose();
    super.dispose();
  }

  void _consumeInvite() {
    final code = pendingInvite.value;
    if (code == null || !mounted || _busy) return;
    pendingInvite.value = null;
    _join(code);
  }

  void _toast(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _create() async {
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) {
        final c = TextEditingController(text: 'Вечер кино');
        return AlertDialog(
          title: const Text('Новая комната'),
          content: TextField(
            controller: c,
            autofocus: true,
            maxLength: 40,
            decoration: const InputDecoration(labelText: 'Название'),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Отмена')),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(110, 44)),
              onPressed: () => Navigator.pop(ctx, c.text),
              child: const Text('Создать'),
            ),
          ],
        );
      },
    );
    if (name == null) return;
    await _guard(() async {
      final code = await RoomService.instance.createRoom(name);
      await _open(code);
    });
  }

  Future<void> _join(String raw) async {
    await _guard(() async {
      final room = await RoomService.instance.joinRoom(raw);
      await _open(room.code);
    });
  }

  Future<void> _guard(Future<void> Function() job) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await job();
    } on RoomException catch (e) {
      _toast(e.message);
    } catch (e) {
      _toast('Что-то пошло не так: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _open(String code) async {
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => RoomScreen(code: code)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final me = widget.me;
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ProfileScreen(
                        initialNick: me.nick,
                        initialAvatar: me.avatarB64,
                      ),
                    ),
                  ),
                  child: AvatarView(nick: me.nick, b64: me.avatarB64, radius: 26),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Привет,',
                          style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant)),
                      Text(me.nick,
                          style: theme.textTheme.titleLarge,
                          overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'Мои эмодзи',
                  icon: const Icon(Icons.emoji_emotions_outlined),
                  onPressed: () => EmojiSheet.show(context),
                ),
              ],
            ),
            const SizedBox(height: 36),
            Text('Syncly',
                style: theme.textTheme.displaySmall
                    ?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text('Одно видео — одна секунда — все вместе.',
                style: theme.textTheme.bodyLarge
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
            const SizedBox(height: 32),
            FilledButton.icon(
              onPressed: _busy ? null : _create,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Создать комнату'),
            ),
            const SizedBox(height: 28),
            Text('Или войдите по коду',
                style: theme.textTheme.labelLarge
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _code,
                    maxLength: 6,
                    textCapitalization: TextCapitalization.characters,
                    style: const TextStyle(letterSpacing: 4, fontSize: 18),
                    decoration: const InputDecoration(
                      hintText: 'ABC234',
                      counterText: '',
                    ),
                    onSubmitted: (v) => _join(v),
                  ),
                ),
                const SizedBox(width: 10),
                SizedBox(
                  width: 56,
                  height: 52,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                        minimumSize: const Size(56, 52),
                        padding: EdgeInsets.zero),
                    onPressed: _busy ? null : () => _join(_code.text),
                    child: const Icon(Icons.arrow_forward_rounded),
                  ),
                ),
              ],
            ),
            if (_busy)
              const Padding(
                padding: EdgeInsets.only(top: 24),
                child: Center(child: CircularProgressIndicator()),
              ),
          ],
        ),
      ),
    );
  }
}
