import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/video_source.dart';
import '../services/room_service.dart';

/// Выбор видео админом: вставить ссылку YouTube / VK Видео / RuTube.
class VideoPickerSheet extends StatefulWidget {
  const VideoPickerSheet({super.key, required this.code, required this.premium});

  final String code;
  final bool premium;

  static Future<void> show(BuildContext context,
      {required String code, required bool premium}) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => VideoPickerSheet(code: code, premium: premium),
    );
  }

  @override
  State<VideoPickerSheet> createState() => _VideoPickerSheetState();
}

class _VideoPickerSheetState extends State<VideoPickerSheet> {
  final _url = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _url.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null) {
      setState(() {
        _url.text = data!.text!;
        _error = null;
      });
    }
  }

  Future<void> _submit() async {
    final parsed = VideoUrlParser.parse(_url.text);
    if (parsed == null) {
      setState(() => _error =
          'Не удалось распознать ссылку. Поддерживаются YouTube, VK Видео и RuTube.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await RoomService.instance.setVideo(widget.code, parsed);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() {
        _busy = false;
        _error = 'Не удалось сменить видео: $e';
      });
    }
  }

  void _driveInfo() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Syncly Plus'),
        content: Text(widget.premium
            ? 'Просмотр файлов с Google Drive появится в ближайшем обновлении.'
            : 'Просмотр личных файлов с Google Drive — в платной подписке Syncly Plus. Скоро!'),
        actions: [
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Понятно'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: EdgeInsets.fromLTRB(
          20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Что смотрим?', style: theme.textTheme.titleLarge),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            children: [
              for (final s in [SourceType.youtube, SourceType.vk, SourceType.rutube])
                Chip(label: Text(s.title)),
              ActionChip(
                avatar: const Icon(Icons.lock_outline, size: 16),
                label: const Text('Google Drive'),
                onPressed: _driveInfo,
              ),
            ],
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _url,
            autofocus: true,
            keyboardType: TextInputType.url,
            minLines: 1,
            maxLines: 3,
            onChanged: (_) => setState(() => _error = null),
            decoration: InputDecoration(
              hintText: 'Вставьте ссылку на видео',
              suffixIcon: IconButton(
                tooltip: 'Вставить',
                icon: const Icon(Icons.content_paste_rounded),
                onPressed: _paste,
              ),
            ),
            onSubmitted: (_) => _submit(),
          ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(_error!,
                  style: TextStyle(color: theme.colorScheme.error)),
            ),
          const SizedBox(height: 8),
          Text(
            'VK: для закрытых видео нужна ссылка встраивания с параметром hash '
            '(«Поделиться» → «Экспортировать»).',
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _busy ? null : _submit,
            child: _busy
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Запустить для всех'),
          ),
        ],
      ),
    );
  }
}
