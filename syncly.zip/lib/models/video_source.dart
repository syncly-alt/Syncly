/// Поддерживаемые источники видео.
enum SourceType { none, youtube, vk, rutube, drive }

extension SourceTypeX on SourceType {
  String get id => name;

  String get title => switch (this) {
        SourceType.none => '—',
        SourceType.youtube => 'YouTube',
        SourceType.vk => 'VK Видео',
        SourceType.rutube => 'RuTube',
        SourceType.drive => 'Google Drive',
      };

  static SourceType parse(String? s) =>
      SourceType.values.firstWhere((e) => e.name == s, orElse: () => SourceType.none);
}

/// Результат разбора ссылки, которую вставил админ.
class ParsedVideo {
  final SourceType type;
  final String id; // youtube: videoId, rutube: 32-hex id, vk: "oid_id"
  final String hash; // только для VK (может быть пустым)
  final String url;

  const ParsedVideo(this.type, this.id, this.url, {this.hash = ''});
}

class VideoUrlParser {
  static final _ytId = RegExp(r'^[A-Za-z0-9_-]{11}$');

  /// Принимает ссылку (или целиком `<iframe ...>` код) и возвращает
  /// нормализованное описание видео либо null.
  static ParsedVideo? parse(String input) {
    var text = input.trim();
    if (text.isEmpty) return null;

    // Если вставили iframe-код — достаём src.
    final src = RegExp(r'''src\s*=\s*["']([^"']+)["']''').firstMatch(text);
    if (src != null) text = src.group(1)!.replaceAll('&amp;', '&');

    return _youtube(text) ?? _rutube(text) ?? _vk(text);
  }

  static ParsedVideo? _youtube(String text) {
    final uri = Uri.tryParse(text.startsWith('http') ? text : 'https://$text');
    if (uri == null) return null;
    final host = uri.host.toLowerCase();
    String? id;
    if (host == 'youtu.be') {
      id = uri.pathSegments.isNotEmpty ? uri.pathSegments.first : null;
    } else if (host.endsWith('youtube.com') ||
        host.endsWith('youtube-nocookie.com')) {
      if (uri.queryParameters['v'] != null) {
        id = uri.queryParameters['v'];
      } else if (uri.pathSegments.length >= 2 &&
          const {'embed', 'shorts', 'live', 'v'}.contains(uri.pathSegments.first)) {
        id = uri.pathSegments[1];
      }
    }
    if (id != null && _ytId.hasMatch(id)) {
      return ParsedVideo(SourceType.youtube, id, text);
    }
    return null;
  }

  static ParsedVideo? _rutube(String text) {
    final m = RegExp(
      r'rutube\.ru/(?:video|play/embed|shorts)/(?:private/)?([0-9a-f]{32})',
      caseSensitive: false,
    ).firstMatch(text);
    if (m == null) return null;
    return ParsedVideo(SourceType.rutube, m.group(1)!.toLowerCase(), text);
  }

  static ParsedVideo? _vk(String text) {
    if (!RegExp(r'(vk\.com|vk\.ru|vkvideo\.ru)', caseSensitive: false)
        .hasMatch(text)) {
      return null;
    }
    String? oid;
    String? id;
    final direct = RegExp(r'video(-?\d+)_(\d+)').firstMatch(text);
    if (direct != null) {
      oid = direct.group(1);
      id = direct.group(2);
    } else {
      oid = RegExp(r'[?&]oid=(-?\d+)').firstMatch(text)?.group(1);
      id = RegExp(r'[?&]id=(\d+)').firstMatch(text)?.group(1);
    }
    if (oid == null || id == null) return null;
    final hash = RegExp(r'[?&]hash=([0-9a-zA-Z]+)').firstMatch(text)?.group(1) ?? '';
    return ParsedVideo(SourceType.vk, '${oid}_$id', text, hash: hash);
  }
}
