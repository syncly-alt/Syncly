import 'package:cloud_firestore/cloud_firestore.dart';
import 'video_source.dart';

class Room {
  final String code;
  final String name;
  final String hostId;
  final SourceType source;
  final String videoId;
  final String videoHash;
  final String videoUrl;
  final List<String> kicked;

  const Room({
    required this.code,
    required this.name,
    required this.hostId,
    required this.source,
    required this.videoId,
    required this.videoHash,
    required this.videoUrl,
    required this.kicked,
  });

  bool get hasVideo => source != SourceType.none && videoId.isNotEmpty;

  /// Ключ видео: меняется → плеер пересоздаётся.
  String get videoKey => '${source.id}|$videoId|$videoHash';

  /// Подпись «значимых» полей: по ней SyncController решает, будить ли UI.
  String get signature =>
      '$hostId|$name|$videoKey|${kicked.join(",")}';

  factory Room.fromMap(String id, Map<String, dynamic> m) {
    return Room(
      code: id,
      name: (m['name'] as String?) ?? 'Комната',
      hostId: (m['hostId'] as String?) ?? '',
      source: SourceTypeX.parse(m['sourceType'] as String?),
      videoId: (m['videoId'] as String?) ?? '',
      videoHash: (m['videoHash'] as String?) ?? '',
      videoUrl: (m['videoUrl'] as String?) ?? '',
      kicked: List<String>.from((m['kicked'] as List?) ?? const []),
    );
  }
}

class Member {
  final String uid;
  final String nick;
  final String? avatarB64;
  final DateTime? joinedAt;
  final DateTime? lastSeen;

  const Member({
    required this.uid,
    required this.nick,
    this.avatarB64,
    this.joinedAt,
    this.lastSeen,
  });

  /// Считаем участника онлайн, если lastSeen свежее 90 секунд
  /// (или ещё не подтверждён сервером).
  bool get online =>
      lastSeen == null || DateTime.now().difference(lastSeen!).inSeconds < 90;

  factory Member.fromDoc(String uid, Map<String, dynamic> m) => Member(
        uid: uid,
        nick: (m['nick'] as String?) ?? 'Гость',
        avatarB64: m['avatarB64'] as String?,
        joinedAt: (m['joinedAt'] as Timestamp?)?.toDate(),
        lastSeen: (m['lastSeen'] as Timestamp?)?.toDate(),
      );
}

class ChatMessage {
  final String id;
  final String userId;
  final String nick;
  final String type; // text | emoji
  final String text;
  final String? emojiB64;
  final DateTime? createdAt;

  const ChatMessage({
    required this.id,
    required this.userId,
    required this.nick,
    required this.type,
    required this.text,
    this.emojiB64,
    this.createdAt,
  });

  factory ChatMessage.fromDoc(String id, Map<String, dynamic> m) => ChatMessage(
        id: id,
        userId: (m['userId'] as String?) ?? '',
        nick: (m['nick'] as String?) ?? '',
        type: (m['type'] as String?) ?? 'text',
        text: (m['text'] as String?) ?? '',
        emojiB64: m['emojiB64'] as String?,
        createdAt: (m['createdAt'] as Timestamp?)?.toDate(),
      );
}

class AppUser {
  final String uid;
  final String nick;
  final String? avatarB64;
  final bool premium;

  const AppUser({
    required this.uid,
    required this.nick,
    this.avatarB64,
    this.premium = false,
  });

  factory AppUser.fromDoc(String uid, Map<String, dynamic> m) => AppUser(
        uid: uid,
        nick: (m['nick'] as String?) ?? 'Гость',
        avatarB64: m['avatarB64'] as String?,
        premium: m['premium'] == true,
      );
}

class CustomEmoji {
  final String id;
  final String b64;
  const CustomEmoji(this.id, this.b64);
}
