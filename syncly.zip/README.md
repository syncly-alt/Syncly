# Syncly — совместный просмотр видео (аналог Rave)

Flutter (iOS + Android) · Firebase Auth/Firestore · YouTube, VK Видео, RuTube.

Комнаты по коду и ссылке-приглашению, управляет только админ, чат с
картинками-эмодзи, профиль с аватаром и ником.

## Что внутри

| Путь | Назначение |
|---|---|
| `lib/sync/sync_controller.dart` | Доработанный SyncController (см. ниже) |
| `lib/players/` | Единый WebView-плеер для YouTube / VK / RuTube + JS-мост |
| `lib/services/` | Авторизация, комнаты, чат, личные эмодзи |
| `lib/screens/` | Профиль, главный экран, комната, выбор видео |
| `firestore.rules` | Правила безопасности (опубликовать в консоли) |
| `test/` | Тесты разбора ссылок |

## Запуск

1. Создайте проект в [Firebase Console](https://console.firebase.google.com):
   включите **Authentication → Anonymous** и **Firestore Database**.
2. Скопируйте `firestore.rules` в *Firestore → Rules* и нажмите **Publish**.
3. Добавьте Android/iOS-приложения в Firebase и положите
   `google-services.json` (в `android/app/`) и `GoogleService-Info.plist`
   (в `ios/Runner/`). Проще всего: `dart pub global activate flutterfire_cli`,
   затем `flutterfire configure`.
4. В папке проекта:
   ```bash
   flutter create . --org com.syncly --project-name syncly   # генерирует android/ и ios/
   flutter pub get
   flutter run
   ```
   Если версии пакетов конфликтуют: `flutter pub upgrade --major-versions`.
   (`share_plus` в коде использует API версии 10: `Share.share`.)

### Настройки платформ

**Android** (`android/app/src/main/AndroidManifest.xml`):
- `<uses-permission android:name="android.permission.INTERNET"/>` (в release его нужно добавить вручную);
- `minSdkVersion 23` в `android/app/build.gradle`;
- внутрь `<activity>` — приглашения по ссылке:
  ```xml
  <intent-filter>
    <action android:name="android.intent.action.VIEW"/>
    <category android:name="android.intent.category.DEFAULT"/>
    <category android:name="android.intent.category.BROWSABLE"/>
    <data android:scheme="syncly" android:host="room"/>
  </intent-filter>
  ```

**iOS** (`ios/Runner/Info.plist`):
```xml
<key>NSPhotoLibraryUsageDescription</key>
<string>Нужен доступ к фото, чтобы выбрать аватар и эмодзи</string>
<key>CFBundleURLTypes</key>
<array><dict>
  <key>CFBundleURLSchemes</key><array><string>syncly</string></array>
</dict></array>
```
Для iOS 13+ в Podfile: `platform :ios, '13.0'`.

> Ссылка-приглашение сейчас `syncly://room/КОД` — она открывает приложение,
> если оно установлено. Чтобы ссылка работала и как обычная `https://…`
> (из мессенджеров), нужен свой домен + Universal Links / App Links.
> Код комнаты работает всегда.

## Что изменено в SyncController (v3.2 → v4)

Исправлены ошибки исходной версии:

1. **Часы устройств расходились** → `extrapolatedPosition` считала время по
   локальным часам, а `updatedAt` — серверное. Теперь при входе замеряется
   сдвиг часов (`_calibrateClock`) и экстраполяция идёт по серверному времени.
2. **`updatedAt == null`** (локальная запись ещё не подтверждена) подставлял
   `DateTime.now()` и давал скачок позиции. Теперь такие снимки пропускаются
   (`hasPendingWrites`), `VideoState.tryParse` возвращает `null`.
3. **Потеря обновлений**: пока шёл `_applyRemote`, новый снимок молча
   отбрасывался. Теперь он ставится в очередь (`_reapply`).
4. **Seek-петли**: добавлены `_seekCooldown` и опережение `_seekLead`;
   на паузе допуск 0.4 с, при воспроизведении 1.2 с (раньше было одно
   значение, а константа `_seekThreshold` не использовалась).
5. **Эхо событий плеера**: окно `_suppressUntil` вместо мёртвого
   `_lastLocalActionAt`, который проверялся только у админа.
6. **Автозахват роли** (`tryTakeOverHost`) раньше требовал ручного вызова —
   теперь зритель сам проверяет heartbeat каждые 10 с (со случайной
   задержкой, итог решает транзакция). Раньше сравнивалось локальное
   время с серверным.
7. **Heartbeat админа без плеера** обновляет только `hostLastSeen`,
   чтобы комнату без видео не считали брошенной.
8. **Экстраполяция ограничена 15 с** — если админ пропал, зрители не
   «убегают» вперёд.
9. **Корректное освобождение**: `dispose()` вместо `disposeAsync()` с
   `super.dispose()` в произвольном месте; таймеры и подписка отменяются.
10. Контроллер сам хранит `Room` (смена видео, исключение, смена админа) —
    UI реагирует через `notifyListeners`.
11. Повторная синхронизация зрителя каждые 4 с по последнему состоянию
    (без обращения к сети), чтобы догонять после буферизации.

Изменения в правилах Firestore: `kicked`/`hostLastSeen` читаются безопасно
(`get(..., default)`), захват роли недоступен исключённым, добавлены
проверки полей и размеров (ник, сообщения, эмодзи, аватар), `premium`
нельзя поменять с клиента, правила для `users/{uid}/emojis`.

## Как это работает

- Админ — тот, чей `hostId` записан в комнате. Только его действия
  (play/pause/перемотка внутри плеера) пишутся в Firestore; у зрителей плеер
  закрыт прозрачным слоем.
- Админ пишет состояние при каждом действии и раз в 5 с (heartbeat).
  Зрители применяют его с поправкой на прошедшее время.
- Админ ушёл → роль получает самый давний онлайн-участник. Приложение
  убито без выхода → через 60 с роль забирает любой зритель.
- Платный источник «Google Drive» — заглушка (диалог «Syncly Plus»);
  флаг `premium` в `users/{uid}` можно менять только из консоли/сервера.

## Известные ограничения

- Код **не запускался и не компилировался** в среде, где он писан (там нет
  Flutter SDK): прогоните `flutter analyze` и `flutter test`.
- YouTube запрещает встраивание части видео — приложение покажет ошибку.
- VK: закрытые видео требуют ссылку со встраиванием (`hash`).
  RuTube/VK JS-API описаны в их документации; поведение плееров может
  меняться, проверяйте на реальных видео.
- Профиль привязан к анонимному входу: при переустановке приложения
  аккаунт теряется (позже можно привязать e-mail/Google).
- Рекламу внутри плееров (preroll) синхронизация не отслеживает.
