import 'package:flutter_test/flutter_test.dart';
import 'package:syncly/models/video_source.dart';

void main() {
  group('VideoUrlParser', () {
    test('YouTube: watch, youtu.be, shorts, embed', () {
      for (final url in [
        'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        'https://youtu.be/dQw4w9WgXcQ?si=abc',
        'https://www.youtube.com/shorts/dQw4w9WgXcQ',
        'https://www.youtube.com/embed/dQw4w9WgXcQ',
        'https://m.youtube.com/watch?v=dQw4w9WgXcQ&t=10s',
      ]) {
        final p = VideoUrlParser.parse(url);
        expect(p?.type, SourceType.youtube, reason: url);
        expect(p?.id, 'dQw4w9WgXcQ', reason: url);
      }
    });

    test('RuTube', () {
      final p = VideoUrlParser.parse(
          'https://rutube.ru/video/0123456789abcdef0123456789abcdef/');
      expect(p?.type, SourceType.rutube);
      expect(p?.id, '0123456789abcdef0123456789abcdef');
    });

    test('VK: обычная ссылка и iframe', () {
      final a = VideoUrlParser.parse('https://vk.com/video-22822305_456241864');
      expect(a?.type, SourceType.vk);
      expect(a?.id, '-22822305_456241864');

      final b = VideoUrlParser.parse(
          '<iframe src="https://vk.com/video_ext.php?oid=-22822305&amp;id=456241864&amp;hash=abc123def456" width="853"></iframe>');
      expect(b?.type, SourceType.vk);
      expect(b?.id, '-22822305_456241864');
      expect(b?.hash, 'abc123def456');
    });

    test('мусор → null', () {
      expect(VideoUrlParser.parse(''), isNull);
      expect(VideoUrlParser.parse('hello world'), isNull);
      expect(VideoUrlParser.parse('https://example.com/video/1'), isNull);
    });
  });
}
